# Paflegis

Portal de Transparência Legislativa da Câmara Municipal de Pedro Afonso - TO. Agrega e normaliza dados de Matérias Legislativas, Normas Jurídicas e Sessões Plenárias a partir do SAPL público.

## Stack

- **Frontend**: React 19 + TypeScript + Vite + Tailwind CSS
- **Backend**: Express (proxy/aggregator for the public SAPL API)
- **AI**: Google Gemini API (optional — used for AI features)
- **Port**: 5000

## Running the app

```bash
npm install
npm run dev
```

The workflow **"Start application"** runs `npm run dev`, which starts the Express + Vite dev server on port 5000.

## Environment variables

| Variable | Required | Description |
|---|---|---|
| `GEMINI_API_KEY` | Optional | Google Gemini API key for AI features |
| `APP_URL` | Optional | Public URL of the hosted app |

## Project structure

- `server.ts` — Express server (API proxy, static file serving, Vite middleware in dev)
- `src/` — React frontend (components, views, lib)
- `src/lib/api/sapl.ts` — SAPL public API client
- `src/views/` — Page-level components
- `src/components/` — Reusable UI components
- `public/` — Static assets (sitemap, robots.txt, ads.txt)

## User preferences

- Keep the existing project structure and stack.
