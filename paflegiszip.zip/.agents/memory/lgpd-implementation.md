---
name: LGPD Implementation
description: Arquitetura de conformidade LGPD completa implementada no Paflegis — Jul/2026.
---

## Decisão Central
`src/lib/consentManager.ts` é o único módulo que toca localStorage para consentimentos. Qualquer componente que precise ler ou escrever preferências deve importar deste módulo.

**Why:** evita inconsistências entre CookieConsent, CentralDePrivacidadeView e PoliticaDeCookiesView que todos precisam de leitura/escrita de preferências.

**How to apply:** Ao adicionar novo cookie ou nova categoria, atualize apenas consentManager.ts e os toggles no CentralDePrivacidadeView.

## Versões de Política (atualizar aqui ao revisar)
- Privacy: `'1.0 — Jul/2026'` (POLICY_VERSIONS.privacy)
- Terms: `'1.0 — Jul/2026'` (POLICY_VERSIONS.terms)
- Cookies: `'1.0 — Jul/2026'` (POLICY_VERSIONS.cookies)

## Novas Rotas Adicionadas
- `politica-de-cookies` → PoliticaDeCookiesView
- `aviso-legal` → AvisoLegalView
- `central-de-privacidade` → CentralDePrivacidadeView (recebe onSelectTab para navegação entre documentos)

## CookieConsent
- Prop `onOpenCookiePolicy` → callback para App.tsx que navega para `politica-de-cookies`
- Script AdSense só carrega após `prefs.marketing === true`

## Campos de Consentimento (6 categorias)
essencial (sempre true), analitico, desempenho, funcional, preferencias, marketing
