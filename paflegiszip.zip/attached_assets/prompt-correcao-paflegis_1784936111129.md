# Prompt para IA: correção do lockfile e reformulação do README do projeto Paflegis

Você vai trabalhar no repositório do projeto Paflegis (portal de transparência legislativa da Câmara Municipal de Pedro Afonso - TO, stack React 19 + Vite + Express + TypeScript). O repositório foi criado originalmente dentro do Replit e carrega alguns resíduos desse ambiente que precisam ser eliminados antes da publicação. Execute as tarefas abaixo, nesta ordem, e documente cada alteração feita.

## Tarefa 1: corrigir o package-lock.json para o registro oficial do npm

O `package-lock.json` atual foi gerado atrás do proxy interno do Replit e todas as entradas `resolved` apontam para `http://package-firewall.replit.local/npm/...` em vez do registro oficial `https://registry.npmjs.org/...`. Faça o seguinte:

1. Verifique se ainda existem ocorrências de `package-firewall.replit.local` ou de qualquer outro domínio que não seja `registry.npmjs.org` no arquivo. Se existirem, substitua pelo endereço oficial, preservando o restante do caminho (escopo do pacote, nome, versão e nome do arquivo `.tgz`), que segue exatamente o mesmo padrão usado pelo npm real.
2. Não altere os campos `integrity` (hashes SHA-512): eles validam o conteúdo do pacote, não a origem, e não devem ser tocados.
3. Depois de corrigir o arquivo manualmente ou via script, rode `npm install` (ou `npm ci`, se o `package.json` não tiver mudado) num ambiente com acesso normal à internet, fora do Replit, para que o npm regenere o lockfile do zero e confirme que todas as versões resolvidas batem com o que o registro oficial de fato distribui. Trate divergências como bug a corrigir, não como algo para ignorar.
4. Confirme ao final que o arquivo é um JSON válido e que nenhuma referência a domínios do Replit restou em nenhum lugar do arquivo (não só em `resolved`, mas em qualquer campo).

## Tarefa 2: eliminar o conflito entre gerenciadores de pacote

O repositório tem dois lockfiles ao mesmo tempo: `package-lock.json` (npm) e `bun.lock` (Bun). Isso é um problema real, não cosmético, pelos seguintes motivos, que você deve verificar antes de agir:

- O `bun.lock` está desatualizado: o campo `name` do workspace nele ainda está como `"react-example"`, um resquício de template que nunca foi corrigido para `"paflegis-app"`.
- O `bun.lock` não lista `express-session` entre as dependências, embora esse pacote esteja no `package.json` e seja importado diretamente em `server.ts` (`import session from 'express-session'`). Uma instalação feita com `bun install` a partir desse lockfile geraria uma árvore de dependências incompleta.
- Plataformas de deploy como Vercel, Netlify, Render e Heroku detectam automaticamente o gerenciador de pacotes pela presença do lockfile. Com os dois arquivos presentes, o comportamento de build passa a depender de qual heurística cada plataforma aplica, o que pode resultar em instalações inconsistentes entre ambientes.

Ação: remova o arquivo `bun.lock` do repositório e garanta que **nenhum** script de build, `Dockerfile` ou configuração de CI faça referência a `bun` em algum ponto. O padrão do projeto inteiro é npm (confirme isso em `Dockerfile`, `Procfile`, `render.yaml`, `vercel.json`, `netlify.toml` e `wrangler.toml`, que já usam `npm ci` / `npm run build` / `npm run start` de forma consistente). Depois de remover o arquivo, adicione uma regra no `.gitignore` ou um comentário no README deixando explícito que o projeto usa exclusivamente npm, para evitar que outro lockfile volte a ser gerado por engano no futuro.

## Tarefa 3: limpar resíduos do ambiente Replit que não devem ir para o repositório público

Antes de publicar, remova do controle de versão (e do próprio diretório de trabalho, quando fizer sentido) os seguintes itens, que são artefatos de ambiente e não fazem parte da aplicação:

- `.agents/` (memória e skills do agente de IA do Replit)
- `.config/.vscode-server` (pasta vazia do servidor remoto do VS Code)
- `assets/.aistudio/` (configuração vazia do Google AI Studio)
- `attached_assets/` (duplica arquivos que já existem em `public/swagger-ui`, além de conter um PDF e um `.txt` de anotações de sessões de trabalho; os nomes de alguns arquivos aqui estão com encoding quebrado, tipo `adequac#U00e7#U00e3o`, o que é mais um indício de que não devem ser versionados)
- `zipFile.zip` (zip aninhado com cópias de arquivos que já existem em outros lugares do projeto)
- Qualquer `.git` embutido que não seja o repositório real de destino, e os remotes do tipo `git+ssh://git@ssh.spock.replit.dev/...` ou `git://gitsafe:.../backup.git`, que são específicos da infraestrutura do Replit

Mantenha `.replit` e `replit.nix` apenas se o desenvolvimento continuar acontecendo dentro do Replit; caso contrário, remova-os também. Ao final desta tarefa, rode `git status` e confirme que a árvore de trabalho está limpa e que só restam arquivos que pertencem de fato à aplicação.

## Tarefa 4: reformular o README.md

Reescreva o `README.md` do zero, em português, para servir como a porta de entrada de quem for clonar o repositório. Ele precisa conter, nesta ordem:

1. **Descrição do projeto**: o que é o Paflegis, para quem serve, e a stack usada (React 19 + TypeScript + Vite no frontend, Express no backend como proxy/agregador da API pública do SAPL, Google Gemini como recurso opcional de IA).

2. **Estrutura do repositório a ser publicada**: uma árvore de diretórios comentada, mostrando exatamente o que compõe o app depois da limpeza feita nas tarefas 2 e 3. Algo no formato:

```
paflegis/
├── src/                  # frontend React + TypeScript
│   ├── components/
│   ├── lib/
│   ├── views/
│   └── types/
├── public/               # ativos estáticos servidos diretamente
│   └── swagger-ui/       # documentação interativa da API
├── scripts/
│   └── post-merge.sh
├── server.ts             # servidor Express (proxy/agregador da API do SAPL)
├── index.html
├── vite.config.ts
├── tsconfig.json
├── package.json
├── package-lock.json
├── .env.example
└── [arquivos de configuração de deploy: Dockerfile, Procfile, heroku.yml,
    netlify.toml, render.yaml, vercel.json, wrangler.toml]
```

Ajuste essa árvore para refletir o estado real do repositório depois da limpeza, não copie o exemplo acima literalmente sem conferir.

3. **Como rodar localmente**: pré-requisitos (versão do Node, conforme `.node-version`/`.nvmrc`), instalação (`npm install`), variáveis de ambiente obrigatórias e opcionais (baseado no `.env.example`: `GEMINI_API_KEY`, `SESSION_SECRET`, `NODE_ENV`, `PORT`, `ALLOWED_ORIGINS`, `STATS_TTL_MS`), e o comando para subir o ambiente de desenvolvimento (`npm run dev`, que sobe Express + Vite na porta 5000).

4. **Instruções de deploy, uma seção por plataforma configurada no projeto**. Para cada uma, explique o que o arquivo de configuração já faz e o que precisa ser configurado manualmente no painel da plataforma:
   - **Docker (Dockerfile + heroku.yml)**: build multi-stage, como buildar e rodar a imagem localmente, e como o Heroku consome isso via `heroku.yml` apontando para o `Dockerfile`.
   - **Heroku (Procfile)**: processo `web: npm run start`, variáveis de ambiente a configurar no painel.
   - **Render (render.yaml)**: deploy como blueprint, `buildCommand` e `startCommand` já definidos, health check em `/api/stats`, quais variáveis são geradas automaticamente (`SESSION_SECRET`) e quais precisam ser preenchidas manualmente (`GEMINI_API_KEY`).
   - **Vercel (vercel.json)**: `buildCommand`, `outputDirectory: dist`, e a ressalva de que rotas `/api/*` precisam de um backend rodando à parte, já que a Vercel aqui está configurada para servir o build estático.
   - **Netlify (netlify.toml)**: publish em `dist`, e a explicação de que o backend Express não roda no Netlify estático, precisando apontar `/api/*` para uma instância rodando em outro lugar (o arquivo já traz um exemplo apontando para Render).
   - **Cloudflare Pages (wrangler.toml)**: `pages_build_output_dir: dist`, comando `wrangler pages deploy dist --project-name=paflegis`, e como configurar secrets via `wrangler secret put`.

   Se alguma dessas plataformas não for de fato utilizada, remova o arquivo de configuração correspondente do repositório (Tarefa 3) e não inclua a seção dela no README, para não gerar expectativa de suporte a algo que não é mantido.

5. **Aviso sobre o gerenciador de pacotes**: uma linha curta deixando explícito que o projeto usa exclusivamente npm e que o `bun.lock` foi removido intencionalmente, para que ninguém reintroduza um segundo lockfile sem querer.

Ao terminar as quatro tarefas, gere um resumo final listando: o que foi corrigido no lockfile, o que foi removido do repositório e por quê, e um link (ou caminho) para o README reformulado.
